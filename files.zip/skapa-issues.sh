#!/usr/bin/env bash
#
# Skapar labels, milstolpar och issues i SebTns/Krav.
#
# Förutsätter GitHub CLI: https://cli.github.com/
#   gh auth login
#   ./skapa-issues.sh
#
# Kör med DRY_RUN=1 ./skapa-issues.sh för att se vad som skulle skapas utan att skapa något.

set -euo pipefail

REPO="SebTns/Krav"
DRY_RUN="${DRY_RUN:-0}"

run() {
  if [ "$DRY_RUN" = "1" ]; then
    printf '[dry-run] %s\n' "$*"
  else
    "$@"
  fi
}

# ---------------------------------------------------------------- labels

label() {
  run gh label create "$1" --repo "$REPO" --color "$2" --description "$3" --force
}

label "krav"          "0e8a16" "Funktionella och icke-funktionella krav"
label "use-case"      "1d76db" "Skriva eller revidera ett use case"
label "dokumentation" "5319e7" "Övriga dokument i docs/"
label "test"          "d93f0b" "Testfall och testbarhet"
label "review"        "fbca04" "Behöver granskas av gruppen"
label "prio-hog"      "b60205" "Måste bli klart först"
label "prio-medel"    "fef2c0" "Görs efter prio-hog"

# ------------------------------------------------------------ milstolpar

milestone() {
  if [ "$DRY_RUN" = "1" ]; then
    printf '[dry-run] milestone: %s (%s)\n' "$1" "$2"
  else
    gh api "repos/$REPO/milestones" -f title="$1" -f due_on="$2" >/dev/null 2>&1 \
      || echo "Milstolpe '$1' finns redan eller kunde inte skapas"
  fi
}

milestone "M1 – Use cases färdiga"    "2026-09-11T23:59:59Z"
milestone "M2 – Kravspecifikation v1" "2026-09-25T23:59:59Z"

# ---------------------------------------------------------------- issues

issue() {
  local title="$1" body="$2" labels="$3" milestone="$4"
  run gh issue create --repo "$REPO" \
    --title "$title" \
    --body "$body" \
    --label "$labels" \
    --milestone "$milestone"
}

# -- M1: use cases --------------------------------------------------------

UC_BODY_TEMPLATE='Filen är tom i repot. Skriv färdigt enligt den gemensamma mallen.

**Checklista**
- [ ] Metadata: Use Case ID, Namn, Version, Primär aktör, Sekundär aktör
- [ ] Beskrivning (1–2 meningar)
- [ ] Förutsättningar
- [ ] Huvudflöde, numrerade steg
- [ ] Alternativa flöden (AF-01, AF-02, ...) med hänvisning till vilket steg de bryter från
- [ ] Postconditions för både lyckat och misslyckat utfall
- [ ] Relaterade FR och NFR ifyllda
- [ ] Stavningskontroll

Mall: se issue om gemensam use case-mall.'

issue "UC-01 Starta nytt parti – skriv färdigt" \
  "$UC_BODY_TEMPLATE

Relaterade krav: FR-03.1 – FR-03.7, NFR-02.1" \
  "use-case,prio-hog" "M1 – Use cases färdiga"

issue "UC-02 Gör ett drag – skriv färdigt" \
  "$UC_BODY_TEMPLATE

Relaterade krav: FR-08.1 – FR-08.13, NFR-02.2, NFR-02.4

Glöm inte alternativa flöden för upptagen ruta och drag utanför tur." \
  "use-case,prio-hog" "M1 – Use cases färdiga"

issue "UC-03 Bjud in en vän – skriv färdigt" \
  "$UC_BODY_TEMPLATE

Relaterade krav: FR-07.1 – FR-07.9, NFR-07.2

Beskriv vad som händer när inbjudan förfaller och när en tredje spelare försöker ansluta." \
  "use-case,prio-hog" "M1 – Use cases färdiga"

issue "UC-04 Välja färg – skriv färdigt" \
  "$UC_BODY_TEMPLATE

Relaterade krav: FR-04.1 – FR-04.7

Ta ställning till konflikten när båda spelarna vill ha svart." \
  "use-case,prio-medel" "M1 – Use cases färdiga"

issue "UC-05 Spela mot datorn – granska och komplettera" \
  'UC-05 är en av två UC som redan har innehåll. Behöver kompletteras till samma format som övriga.

**Checklista**
- [ ] Lägg till metadatatabell (ID, Namn, Version, Primär/Sekundär aktör)
- [ ] Lägg till Relaterade FR och NFR
- [ ] Rätta stavning och versaler i stegen
- [ ] Numrera de alternativa flödena mot rätt steg i huvudflödet
- [ ] Lägg till postcondition för misslyckat utfall

Relaterade krav: FR-06.1 – FR-06.8, NFR-02.3' \
  "use-case,review,prio-hog" "M1 – Use cases färdiga"

issue "UC-06 Starta spelet – skriv färdigt" \
  "$UC_BODY_TEMPLATE

Relaterade krav: FR-01.1 – FR-01.5, NFR-01.*

Avgränsa mot UC-01: detta UC handlar om att öppna applikationen, inte om att starta ett parti." \
  "use-case,prio-hog" "M1 – Use cases färdiga"

issue "UC-07 Välj ditt synliga spelarnamn – skriv färdigt" \
  "$UC_BODY_TEMPLATE

Relaterade krav: FR-02.1 – FR-02.7, NFR-07.3

Beskriv valideringsreglerna för namnet i huvudflödet." \
  "use-case,prio-medel" "M1 – Use cases färdiga"

issue "UC-08 Välj svårighetsgrad – skriv färdigt" \
  "$UC_BODY_TEMPLATE

Relaterade krav: FR-05.1 – FR-05.7

Avgränsa mot UC-05: här väljs graden, i UC-05 spelas partiet." \
  "use-case,prio-medel" "M1 – Use cases färdiga"

issue "Gemensam mall för use cases" \
  'Alla UC ska följa samma struktur så att de går att jämföra och testa.

**Att göra**
- [ ] Skapa `docs/requirements/use-cases/_MALL.md`
- [ ] Bestäm rubriknivåer och metadatatabell
- [ ] Bestäm namngivning av alternativa flöden (AF-01, AF-02 ...)
- [ ] Förankra mallen i gruppen innan alla börjar skriva

Lärarens repo har ett bra exempel i `docs/requirements/use-cases/UC-01-start-a-new-game.md`.' \
  "use-case,prio-hog" "M1 – Use cases färdiga"

issue "Rensa i UC-listan: dubbletter och överlapp" \
  'Repot har 32 UC-filer och flera överlappar varandra.

**Att besluta**
- [ ] UC-01 vs UC-13 (båda heter "starta nytt parti")
- [ ] UC-11 "ge upp" vs UC-12 "avsluta ett parti"
- [ ] UC-14/15/16 (oavgjort, förlust, vinst) — egna UC eller utfall i UC-02?
- [ ] UC-02 vs UC-09 (spelarens drag vs motståndarens drag)
- [ ] Ta bort eller slå ihop de som blir kvar utan eget syfte

Beslutet dokumenteras i `09-journal.md`.' \
  "use-case,review,prio-hog" "M1 – Use cases färdiga"

# -- M2: kravdokument -----------------------------------------------------

issue "02 Funktionella krav – ersätt user stories med systemkrav" \
  'Filen innehåller idag user stories, vilket står i en varning högst upp i filen. De ska
skrivas om som verifierbara krav på formen "Systemet ska ...".

**Att göra**
- [ ] Numrera kraven som FR-XX.Y
- [ ] Ett krav = en mening = en testbar sak
- [ ] Koppla varje FR-grupp till det UC den realiserar
- [ ] Ta bort lösningsförslag ur kravtexten
- [ ] Ta bort varningsrubriken när filen är klar

Utkast finns framtaget för FR-01 till FR-08 baserat på UC-01 – UC-08.' \
  "krav,prio-hog" "M2 – Kravspecifikation v1"

issue "04 Icke-funktionella krav – gör kraven mätbara" \
  'Filen listar i dag bara fem rubriker utan innehåll. Varje NFR behöver ett mätbart värde,
annars går det inte att testa.

**Att göra**
- [ ] Numrera som NFR-XX.Y
- [ ] Sätt ett siffervärde eller en tydlig gräns på varje krav
- [ ] Flytta "rapportering av problem" och "moderering" — själva funktionen hör hemma i 02
- [ ] Lägg till kategorier för användbarhet, säkerhet, tillförlitlighet och testbarhet' \
  "krav,prio-hog" "M2 – Kravspecifikation v1"

issue "03 Kompletterande krav – fylla i" \
  'Filen är tom. Här hör begränsningar och antaganden hemma: teknikval, avgränsningar,
vad som är utanför scope för v1.' \
  "krav,prio-medel" "M2 – Kravspecifikation v1"

issue "00 Begreppslista – komplettera" \
  'Domäntermerna är påbörjade, GDPR-termer och tekniska termer är tomma.

**Att göra**
- [ ] Fyll på domäntermer: drag, parti, sten, skärningspunkt, fem i rad, svårighetsgrad
- [ ] GDPR-termer: personuppgift, samtycke, personuppgiftsansvarig
- [ ] Tekniska termer: partitillstånd, inbjudningskod, sessionsdata
- [ ] Rätta stavningen i rubrikerna ("Begräppslista")' \
  "dokumentation,prio-medel" "M2 – Kravspecifikation v1"

issue "05 Begreppsmodell" \
  'Filen är tom. Rita en klass- eller domänmodell med Spelare, Parti, Bräde, Drag, Sten,
Inbjudan och Rapport samt relationerna mellan dem.' \
  "dokumentation,prio-medel" "M2 – Kravspecifikation v1"

issue "06 User journey" \
  'Filen är tom. Rita minst två flöden: ny spelare som spelar mot datorn, och spelare som
bjuder in en vän. Mermaid fungerar direkt i GitHub.' \
  "dokumentation,prio-medel" "M2 – Kravspecifikation v1"

issue "07 Use cases overview – aktörer och prioritering" \
  'Filen är tom. Behöver en tabell över alla UC med aktör, prioritet och status samt en
aktörslista (Spelare, Gäst, Datorn, Administratör).' \
  "dokumentation,prio-hog" "M2 – Kravspecifikation v1"

issue "10 Spårbarhetsmatris UC ↔ FR ↔ NFR" \
  'Skapa en matris som visar att varje FR realiseras av minst ett UC och att varje UC har
bakomliggande krav. Används för att hitta luckor innan inlämning.

Utkast finns framtaget för UC-01 – UC-08.' \
  "krav,review,prio-hog" "M2 – Kravspecifikation v1"

issue "08 Testfall per use case" \
  'Filen `08-use-cases-och-test-cases.md` är tom. Varje UC behöver testfall som täcker
huvudflödet och varje alternativt flöde.

**Format per testfall**
- Testfall-ID och kopplat FR/UC
- Förutsättning
- Teststeg
- Förväntat resultat

**Täckningskrav**
- [ ] Minst ett testfall per huvudflöde
- [ ] Minst ett testfall per alternativt flöde
- [ ] Minst ett negativt testfall per validering (upptagen ruta, ogiltigt namn, förfallen inbjudan)' \
  "test,prio-hog" "M2 – Kravspecifikation v1"

issue "09 Journal – börja logga gruppens beslut" \
  'Filen är tom. Logga datum, beslut och motivering löpande — särskilt de avgränsningar som
görs kring överlappande UC. Behövs vid redovisningen.' \
  "dokumentation,prio-medel" "M2 – Kravspecifikation v1"

issue "10 Reflektioner" \
  'Filen är tom. Skrivs sist, men lägg upp rubrikerna nu så att alla kan fylla på under arbetets gång.' \
  "dokumentation,prio-medel" "M2 – Kravspecifikation v1"

issue "README – innehållsförteckning över kravdokumenten" \
  'README innehåller i dag bara testtext. Ersätt med en riktig ingång till projektet.

**Att göra**
- [ ] Kort beskrivning av projektet
- [ ] Tabell med länkar till alla dokument i `docs/requirements/`
- [ ] Tabell med länkar till alla use cases
- [ ] Vilka som ingår i gruppen

Lärarens README är en bra förlaga.' \
  "dokumentation,prio-hog" "M2 – Kravspecifikation v1"

issue "Rensa bort tom katalog Krav/ i repo-roten" \
  'Repot innehåller en tom katalog `Krav/` vid sidan av `gomoku/`. Ta bort den eller
förklara vad den ska användas till.' \
  "dokumentation,prio-medel" "M2 – Kravspecifikation v1"

echo
echo "Klart. Kör 'gh issue list --repo $REPO' för att se resultatet."

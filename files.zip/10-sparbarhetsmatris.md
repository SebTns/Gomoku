# 10. Spårbarhetsmatris

Matrisen kopplar ihop use cases, funktionella krav och icke-funktionella krav.
Den används för att kontrollera tre saker:

- **Fullständighet** — varje FR realiseras av minst ett UC.
- **Konsistens** — inget UC saknar bakomliggande FR.
- **Täckning** — varje FR går att testa via sitt UC.

---

## 10.1 Use case → funktionella krav → icke-funktionella krav

| UC | Namn | Funktionella krav | Icke-funktionella krav |
|----|------|-------------------|------------------------|
| UC-01 | Starta nytt parti | FR-03.1 – FR-03.7 | NFR-02.1, NFR-02.7, NFR-04.1 |
| UC-02 | Gör ett drag | FR-08.1 – FR-08.13 | NFR-02.2, NFR-02.4, NFR-06.3, NFR-06.5 |
| UC-03 | Bjud in en vän | FR-07.1 – FR-07.9 | NFR-02.5, NFR-02.6, NFR-04.3, NFR-07.2 |
| UC-04 | Välja färg | FR-04.1 – FR-04.7 | NFR-06.3 |
| UC-05 | Spela mot datorn | FR-06.1 – FR-06.8, FR-08.8 | NFR-02.3, NFR-04.2, NFR-04.6, NFR-09.3 |
| UC-06 | Starta spelet | FR-01.1 – FR-01.5 | NFR-01.1 – NFR-01.6, NFR-02.1, NFR-06.6 |
| UC-07 | Välj ditt synliga spelarnamn | FR-02.1 – FR-02.7 | NFR-07.3, NFR-07.4 |
| UC-08 | Välj svårighetsgrad | FR-05.1 – FR-05.7 | NFR-02.3, NFR-02.7 |

---

## 10.2 Funktionellt krav → use case

| FR | Kort beskrivning | Realiseras av |
|----|-----------------|---------------|
| FR-01 | Applikationsstart | UC-06 |
| FR-02 | Synligt spelarnamn | UC-07 |
| FR-03 | Starta nytt parti | UC-01, UC-13 |
| FR-04 | Välja färg | UC-04 |
| FR-05 | Välja svårighetsgrad | UC-08, UC-05 |
| FR-06 | Spela mot datorn | UC-05, UC-09 |
| FR-07 | Bjuda in en vän | UC-03, UC-10 |
| FR-08 | Göra ett drag | UC-02, UC-09, UC-14, UC-16 |

---

## 10.3 Luckor att stänga

| Lucka | Åtgärd |
|-------|--------|
| UC-09 till UC-32 saknar krav i `02-funktionella-krav.md` | Skriv färdigt respektive UC, härled därefter FR |
| UC-14, UC-15, UC-16 (oavgjort, förlust, vinst) överlappar FR-08.8 – FR-08.11 | Bestäm om utfallen ska vara egna UC eller alternativa flöden i UC-02 |
| UC-13 "Starta ett nytt parti" dubblerar UC-01 | Slå ihop eller avgränsa tydligt (nytt parti från startsidan vs. från avslutat parti) |
| UC-12 "Avsluta ett parti" och UC-11 "Ge upp" överlappar | Avgränsa: ge upp = avbryta pågående, avsluta = normalt slut |
| NFR-09 saknar ägare | Utse ansvarig för testinfrastruktur i gruppen |
